# Licenc

Copyright (c) [2026] [Szabó Gergely]

Ez a szoftver a **Creative Commons Nevezd meg! – Ne add el! – Így add tovább! 4.0 Nemzetközi (CC BY-NC-SA 4.0)** licenc feltételei szerint érhető el, az alábbi kiegészítő magyarázó záradékkal együtt.

A hivatalos, jogilag kötelező érvényű licencszöveg itt olvasható:
https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.hu

Emberi nyelvre lefordított, rövid összefoglaló (nem helyettesíti a fenti hivatalos szöveget):
https://creativecommons.org/licenses/by-nc-sa/4.0/deed.hu

---

## Ez a licenc engedélyezi

- A szoftver **szabad felhasználását**, akár magán-, akár üzleti/céges környezetben, **belső célra** (pl. adatok rögzítésére, saját munkafolyamat támogatására), amíg ez a felhasználás nem jár a szoftver vagy módosított változatának **továbbadásával, terjesztésével vagy nyilvánosan elérhetővé tételével**.
- A forráskód **megtekintését, tanulmányozását, módosítását**.
- A módosított változat továbbadását, **kizárólag** akkor, ha az is ugyanezen licenc (CC BY-NC-SA 4.0 + ez a záradék) alatt kerül továbbadásra, a szerző nevének feltüntetésével.

## Ez a licenc TILTJA

- A szoftver vagy bármely módosított/származékos változatának **értékesítését**, akár pénzért, akár egyéb ellenszolgáltatásért.
- A szoftver vagy módosított változatának **nyilvános terjesztését** (pl. weboldalon közzététel, letöltési linkként megosztás, alkalmazásboltban való elhelyezés) **akkor is, ha az ingyenes**, kivéve ha a terjesztés megfelel ennek a licencnek (vagyis: forráskód elérhető, szerzőség feltüntetve, ugyanezen licenc alatt).
- A szoftver **beépítését más termékbe vagy szolgáltatásba**, amit harmadik félnek kínálnak (akár ingyen, akár pénzért).

## Kiegészítő magyarázat (Iroda vs. nyilvános terjesztés)

Annak egyértelművé tétele érdekében, hogy mi számít "nem kereskedelmi" (NonCommercial) felhasználásnak ezen licenc szerint:

**Megengedett** – belső, nem-terjesztési célú használat:
> Példa: a szoftvert egy munkahelyi gépen elindítod, adatokat rögzítesz vele (pl. bevételt), elmented a fájlt, és azt kizárólag saját/céges belső célra használod tovább. Ez akkor is megengedett, ha a cég profitorientált.

**Nem megengedett** – nyilvános terjesztés, akár ingyenesen is:
> Példa: a szoftvert vagy módosított változatát kiteszed egy weboldalra letölthetőnek, megosztod egy szoftverboltban, vagy beépíted egy másik, harmadik feleknek kínált termékbe/szolgáltatásba — függetlenül attól, hogy ezért kérsz-e pénzt.

Kétség esetén: ha a tevékenység a szoftver **továbbadását** jelenti bárki számára, aki nem te vagy a saját szervezeted, azt terjesztésnek kell tekinteni, és a fenti licencfeltételek (forráskód elérhetősége, szerzőség, azonos licenc) betartása kötelező.

---

**A licenc rövid összefoglalása:**

| | |
|---|---|
| ✅ Ingyenes használat, magán vagy céges belső célra | Igen |
| ✅ Forráskód megtekintése, tanulmányozása | Igen |
| ✅ Módosítás, saját célra | Igen |
| ✅ Módosított változat megosztása | Igen, ha ugyanez a licenc marad rajta |
| ❌ Eladás, pénzért kínálás | Nem |
| ❌ Nyilvános terjesztés (weboldal, bolt), akár ingyen is | Nem, csak ugyanezen licenc alatt |
| ❌ Beépítés más, harmadik félnek szánt termékbe | Nem |

---

*Ez a dokumentum a CC BY-NC-SA 4.0 licencet egészíti ki egy magyarázó záradékkal. Vita esetén a hivatalos CC BY-NC-SA 4.0 jogi szöveg az irányadó, ezt a záradékot pedig a szerző szándékának tisztázására kell figyelembe venni.*